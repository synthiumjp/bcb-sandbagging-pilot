"""
Local configuration — set your GGUF model paths here.
This file is NOT committed to version control.
"""

MODEL_PATHS = {
    "qwen2.5-7b": r"C:\sdt_calibration\models\Qwen2.5-7B-Instruct-Q5_K_M.gguf",
    "llama3-8b": r"C:\sdt_calibration\models\Meta-Llama-3-8B-Instruct-Q5_K_M.gguf",
    "phi3.5-mini": r"D:\bcb_pilot\models\Phi-3.5-mini-instruct-Q5_K_M.gguf",
}
